const mapperForecast = {
    sunrise: "Dawn",
    sunset: "Dusk",
    moonrise: "moonlit",
    moonset: "moonsleep",
    moon_phase: "orientation",
    moon_illumination: "Illumination"
}

export default mapperForecast;