const mapperCurrent = {
    name: "town",
    region: "state",
    country: "Nation",
    lat: "latitude",
    lon: "longitude",
    tz_id: "Time Zone",
    localtime: "Time"
}

export default mapperCurrent;